<footer class="bg-light text-center text-lg-start mt-4">
<div class="news-container" style="max-width: 1200px; margin: 40px auto;">
    <h2 style="text-transform: uppercase; font-weight: bold; font-size: 30px;">Tin tức</h2>
    <div class="news-list" style="display: flex; flex-wrap: wrap; justify-content: space-between;">
        <?php 
        // Mảng chứa danh sách tin tức
        $news = [
            [
                "title" => "Xiaomi YU7 Lộ Nội Thất Hiện Đại, Sẵn Sàng Ra Mắt Thị Trường",
                "description" => "Xiaomi YU7 gây ấn tượng với thiết kế mang phong cách tương lai, tích hợp nhiều công nghệ hiện đại...",
                "image" => "/webbanhang/uploads/news/1.PNG",
                "link" => "https://auto88.vn/news/288/40/xiaomi-yu7-lo-noi-that-hien-dai-san-sang-ra-mat-thi-truong"
            ],
            [
                "title" => "Hyundai Palisade Ưu Đãi Lớn 100 Triệu Đồng, Cạnh Tranh Mạnh Trong Phân Khúc",
                "description" => "Nhiều đại lý Hyundai đang triển khai chương trình giảm giá lên đến 100 triệu đồng cho mẫu Palisade...",
                "image" => "/webbanhang/uploads/news/2.PNG",
                "link" => "https://auto88.vn/news/287/40/hyundai-palisade-uu-dai-lon-100-trieu-dong-canh-tranh-manh-trong-phan-khuc"
            ],
            [
                "title" => "Những Mẹo Đơn Giản Giúp Bảo Vệ Ô Tô Khỏi Trầy Xước",
                "description" => "Những vết xước trên ô tô không chỉ làm giảm tính thẩm mỹ của xe mà còn có thể dẫn đến chi phí sửa...",
                "image" => "/webbanhang/uploads/news/3.PNG",
                "link" => "https://auto88.vn/news/286/40/nhung-meo-don-gian-giup-bao-ve-o-to-khoi-tray-xuoc"
            ],
            [
                "title" => "New Peugeot 2008 Ra Mắt Tại Việt Nam Với 2 Phiên Bản, Giá Bán Vẫn Chưa Được Công Bố",
                "description" => "New Peugeot 2008 chính thức ra mắt tại Việt Nam với hai phiên bản GT và Premium, nâng cấp toàn...",
                "image" => "/webbanhang/uploads/news/4.PNG",
                "link" => "https://auto88.vn/news/285/40/new-peugeot-2008-ra-mat-tai-viet-nam-voi-2-phien-ban-gia-ban-van-chua-duoc-cong-bo"
            ]
        ];

        // Hiển thị từng bài báo
        foreach ($news as $article): ?>
            <div class="news-item" style="display: flex; width: 48%; margin-bottom: 30px; align-items: center; border-bottom: 1px solid #ddd; padding-bottom: 10px;">
                <div style="flex: 1;">
                    <h3 style="font-size: 18px; margin: 0;">
                        <a href="<?php echo htmlspecialchars($article['link']); ?>" target="_blank" style="color: #000; text-decoration: none; font-weight: bold;">
                            <?php echo htmlspecialchars($article['title']); ?>
                        </a>
                    </h3>
                    <p style="font-size: 14px; color: #666; margin-top: 5px;"><?php echo htmlspecialchars($article['description']); ?></p>
                </div>
                <div style="margin-left: 10px;">
                    <a href="<?php echo htmlspecialchars($article['link']); ?>" target="_blank">
                        <img src="<?php echo htmlspecialchars($article['image']); ?>" alt="news image" style="width: 120px; height: 80px; object-fit: cover; border-radius: 5px;">
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<!-- Dòng bản quyền -->
<div class="text-center p-3 bg-dark text-white">
        © 2025 Quản lý sản phẩm. All rights reserved.
    </div>
</footer>

<!-- Font Awesome Icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
🔹 Cải tiến so với phiên bản trước: