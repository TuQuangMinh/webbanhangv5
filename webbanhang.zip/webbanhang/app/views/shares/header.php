<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý sản phẩm</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .product-image {
            max-width: 110px;
            height: auto;
        }
        /* Logo */
        .logo-container {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 120px; /* Tăng kích thước */
            width: 200px; /* Tăng chiều rộng */
            background-color: white;
            border: 3px solid #ddd; /* Viền nổi bật */
            overflow: hidden; /* Ngăn logo bị lệch */
        }
        .logo {
            width: 100%;
            height: 100%;
            object-fit: cover; /* Phóng to logo để vừa khung */
        }
        /* Menu */
        .navbar-nav .nav-link {
            font-size: 20px;  /* Chữ to hơn */
            font-weight: bold; /* Chữ đậm hơn */
        }
    </style>
</head>
<body>
    <!-- Thanh điều hướng -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto"> <!-- Menu nằm bên phải -->
                <li class="nav-item">
                    <a class="nav-link" href="/webbanhang/Product/">Trang Chủ</a>
                </li>
               
                
                <li class="nav-item">
                    <?php
                    if(SessionHelper::isLoggedIn()) {
                        echo "<a class='nav-link'>" . $_SESSION['username'] . "</a>";
                    } else {
                        echo "<a class='nav-link' href='/webbanhang/account/login'>Đăng nhập</a>";
                    }
                    ?>
                </li>
                <li class="nav-item">
                    <?php
                    if(SessionHelper::isLoggedIn()) {
                        echo "<a class='nav-link' href='/webbanhang/account/logout'>Đăng xuất</a>";
                    }
                    ?>
                </li>
            </ul>
        </div>
    </nav>

    

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
