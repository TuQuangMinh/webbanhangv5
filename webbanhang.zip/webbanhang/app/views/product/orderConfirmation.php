<?php include 'app/views/shares/header.php'; ?>
<div class="container py-6">
    <h1 class="text-3xl font-bold text-gray-800">Xác nhận đơn hàng</h1>
    <p class="mt-3">Cảm ơn bạn đã đặt hàng. Đơn hàng của bạn đã được xử lý thành công.</p>
    <a href="/webbanhang/Product" class="btn btn-primary mt-2">Tiếp tục mua sắm</a>
</div>
<?php include 'app/views/shares/footer.php'; ?>