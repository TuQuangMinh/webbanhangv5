<?php include 'app/views/shares/header.php'; ?> <!-- Bao gồm phần đầu trang -->

<?php if (!isset($product)) {
    echo "<p style='text-align: center; font-size: 20px; color: red;'>Sản phẩm không tồn tại.</p>";
    exit;
} ?>

<div class="container" style="max-width: 1200px; margin: 40px auto; padding: 20px; background: #fff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);">
    <h1 style="text-align: center; font-size: 36px; margin-bottom: 20px;">Chi Tiết Sản Phẩm</h1>
    
    <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center;">
        <!-- Ảnh sản phẩm -->
        <div style="flex: 1; text-align: center; padding: 20px;">
            <img src="/webbanhang/<?php echo htmlspecialchars($product->image, ENT_QUOTES, 'UTF-8'); ?>" 
                 alt="<?php echo htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?>" 
                 style="max-width: 100%; height: auto; border-radius: 10px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);">
        </div>
        
        <!-- Thông tin sản phẩm -->
        <div style="flex: 1; padding: 20px;">
            <h2 style="font-size: 28px; margin-bottom: 10px; color: #2c3e50;">
                <?php echo htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?>
            </h2>
            <p style="font-size: 18px; margin-bottom: 10px;"><strong>Mô tả:</strong> <?php echo nl2br(htmlspecialchars($product->description, ENT_QUOTES, 'UTF-8')); ?></p>
            <p style="font-size: 20px; font-weight: bold; color: #e74c3c;">Giá: <?php echo htmlspecialchars($product->price, ENT_QUOTES, 'UTF-8'); ?> VND</p>
            <p>Danh mục: <?php echo isset($product->category_name) ? htmlspecialchars($product->category_name, ENT_QUOTES, 'UTF-8') : 'Không xác định'; ?></p>

            
            <div style="margin-top: 20px;">
            
                
                <a href="/webbanhang/Product/addToCart/<?php echo $product->id; ?>" 
                   class="btn btn-success" 
                   style="padding: 15px 30px; font-size: 18px; margin-left: 10px;">Thêm vào giỏ hàng</a>
            </div>
        </div>
    </div>
</div>

<!-- Phần bình luận -->
<div style="margin-top: 40px;">
        <h3 style="font-size: 24px; margin-bottom: 15px;">Bình luận</h3>
        <form action="/webbanhang/Product/addComment/<?php echo $product->id; ?>" method="post">
            <textarea name="comment" rows="4" style="width: 100%; padding: 10px; font-size: 16px;" placeholder="Nhập bình luận của bạn..."></textarea>
            <button type="submit" style="margin-top: 10px; padding: 10px 20px; font-size: 16px; background: #3498db; color: white; border: none; cursor: pointer;">Gửi bình luận</button>
        </form>
        
        <!-- Hiển thị danh sách bình luận -->
        <div style="margin-top: 20px;">
            <?php if (!empty($comments)) : ?>
                <?php foreach ($comments as $comment) : ?>
                    <div style="padding: 10px; border-bottom: 1px solid #ddd;">
                        <p><strong><?php echo htmlspecialchars($comment->user_name, ENT_QUOTES, 'UTF-8'); ?>:</strong></p>
                        <p><?php echo nl2br(htmlspecialchars($comment->content, ENT_QUOTES, 'UTF-8')); ?></p>
                        <p style="font-size: 12px; color: gray;">Ngày: <?php echo htmlspecialchars($comment->created_at, ENT_QUOTES, 'UTF-8'); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <p>Chưa có bình luận nào.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<a href="/webbanhang" class="btn btn-primary" style="display: block; width: 200px; margin: 40px auto; text-align: center; font-size: 18px;">Quay lại danh sách</a>

<?php include 'app/views/shares/footer.php'; ?>