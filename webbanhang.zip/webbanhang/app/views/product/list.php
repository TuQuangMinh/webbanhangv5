<?php include 'app/views/shares/header.php'; ?>

<!-- Banner -->
<div class="banner" style="background: linear-gradient(to right, #2c3e50, #95a5a6); color: #ffffff; padding: 15px; text-align: center; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5); width: 100%; margin: 0;">
    <h1 style="font-size: 56px; font-weight: bold; text-transform: uppercase;">MINH AUTO</h1>
    <p style="font-size: 24px;">CHUYÊN KINH DOANH XE SANG</p>
</div>

<!-- Bộ lọc -->
<div style="text-align: center; margin: 20px 0;">
    <label for="filter-category" style="font-size: 18px;">Lọc theo danh mục:</label>
    <select id="filter-category" onchange="filterProducts()" style="padding: 5px; font-size: 16px;">
        <option value="all">Tất cả</option>
        <option value="Sedan Hạng Sang">Sedan Hạng Sang</option>
        <option value="SUV Hạng Sang">SUV Hạng Sang</option>
        <option value="Xe Thể Thao">Xe Thể Thao</option>
        <option value="Siêu Xe">Siêu Xe</option>
        <option value="Xe Điện Cao Cấp">Xe Điện Cao Cấp</option>
    </select>
</div>

<!-- Bộ lọc và sắp xếp -->
<div style="text-align: center; margin: 20px 0;">
    <label for="sort-price" style="font-size: 18px;">Sắp xếp theo giá:</label>
    <select id="sort-price" onchange="sortProducts()" style="padding: 5px; font-size: 16px;">
        <option value="default">Mặc định</option>
        <option value="asc">Giá tăng dần</option>
        <option value="desc">Giá giảm dần</option>
    </select>
</div>

<!-- Danh sách sản phẩm -->
<h1 style="text-align: center; margin: 40px 0; font-size: 36px;">Danh sách sản phẩm</h1>
<div id="product-list" style="display: flex; flex-wrap: wrap; justify-content: center; max-width: 1500px; margin: 0 auto;"></div>

<?php include 'app/views/shares/footer.php'; ?>

<script>
document.addEventListener("DOMContentLoaded", function() {
    fetch('/webbanhang/api/product')
    .then(response => response.json())
    .then(data => {
        window.products = data;
        renderProducts(data);
    });
});

function renderProducts(products) {
    const productList = document.getElementById('product-list');
    productList.innerHTML = "";
    products.forEach(product => {
        const productItem = document.createElement('div');
        productItem.className = 'product-item';
        productItem.style = 'flex: 0 1 calc(33.33% - 40px); margin: 20px; border: 2px solid #34495e; border-radius: 8px; padding: 10px; background-color: #ecf0f1; text-align: center; transition: transform 0.3s ease-in-out; cursor: pointer;';
        
        productItem.innerHTML = `
            <img src="${product.image}" alt="${product.name}" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px;">
            <h2>${product.name}</h2>
            <p>${product.description}</p>
            <p><strong>Giá:</strong> ${product.price} VND</p>
            <p class="category-name"><strong>Danh mục:</strong> ${product.category_name}</p>
        `;

        productItem.addEventListener("click", function() {
            window.location.href = `/webbanhang/Product/show/${product.id}`;
        });

        productList.appendChild(productItem);
    });
}

function filterProducts() {
    let category = document.getElementById("filter-category").value;
    let filteredProducts = category === "all" ? window.products : window.products.filter(p => p.category_name === category);
    renderProducts(filteredProducts);
}

function sortProducts() {
    let productContainer = document.getElementById("product-list");
    let products = Array.from(productContainer.getElementsByClassName("product-item"));
    let sortOption = document.getElementById("sort-price").value;

    if (sortOption === "default") {
        window.location.reload();
        return;
    }

    products.sort((a, b) => {
        let priceA = parseFloat(a.querySelector("p:nth-of-type(2)").textContent.replace(/\D/g, ""));
        let priceB = parseFloat(b.querySelector("p:nth-of-type(2)").textContent.replace(/\D/g, ""));
        return sortOption === "asc" ? priceA - priceB : priceB - priceA;
    });

    products.forEach(product => productContainer.appendChild(product));
}
</script>
